# Extension Chrome — Pandonymus Rescue Fix

Captura el redirect OAuth de Lenovo ID (igual que el WebView de Panda) y lo entrega a la app en `pandonymus.com/pandaresuce` o `localhost`. No lee contrasenas.

## Instalar (sin publicar)

1. Chrome o Edge -> `chrome://extensions`
2. Activa **Modo de desarrollador**
3. **Cargar descomprimida** -> carpeta `extension` de este proyecto

## Uso

1. Abre https://www.pandonymus.com/pandaresuce (o `npm.cmd run dev` en localhost:3000)
2. Pulsa **Iniciar sesion Lenovo ID**
3. Entra en la pagina oficial de Lenovo
4. La extension detecta `softwarefix://` o `lenovoIdSuccess.html?code=` y completa el login en la app
