const MAX_AGE_MS = 3 * 60 * 1000;
const FIRST_FLUSH_BYTES = 64 * 1024;
const STREAM_CHUNK_BYTES = 1024 * 1024;
const BASE64_CHUNK_BYTES = 256 * 1024;
const RANGE_PROBE_END = FIRST_FLUSH_BYTES - 1;
const RANGE_FALLBACK_BYTES = 8 * 1024 * 1024;
const HIGH_WATER_BYTES = 16 * 1024 * 1024;
const FIRST_ACK_TIMEOUT_MS = 2_000;
const FIRMWARE_FETCH_TIMEOUT_MS = 60_000;
const FIRMWARE_READ_STALL_MS = 60_000;
let pendingCode = null;
let pendingTimer = 0;
const activeFirmwareDownloads = new Map();

const BADGE_TICK_MS = 400;
const BADGE_CYAN = "#00f5ff";
const BADGE_GREEN = "#39ff14";
let badgeTimer = 0;
let badgeKind = null;
let badgePhase = 0;
let oauthWaiting = false;
let okBadgeTimer = 0;

function stopBadgeTimer() {
  if (badgeTimer) {
    clearInterval(badgeTimer);
    badgeTimer = 0;
  }
}

function applyIdleBadge() {
  void chrome.action.setBadgeText({ text: "" });
}

function startBadgeCycle(kind) {
  if (badgeKind === kind && badgeTimer) return;
  stopBadgeTimer();
  badgeKind = kind;
  badgePhase = 0;
  const tick = () => {
    badgePhase = (badgePhase + 1) % 2;
    const on = badgePhase === 1;
    void chrome.action.setBadgeText({ text: on ? (kind === "download" ? "DL" : "ID") : "•••" });
    void chrome.action.setBadgeBackgroundColor({ color: on ? BADGE_CYAN : BADGE_GREEN });
  };
  tick();
  badgeTimer = setInterval(tick, BADGE_TICK_MS);
}

function refreshBusyBadge() {
  if (okBadgeTimer) {
    clearTimeout(okBadgeTimer);
    okBadgeTimer = 0;
  }
  if (activeFirmwareDownloads.size > 0) {
    startBadgeCycle("download");
    return;
  }
  if (oauthWaiting) {
    startBadgeCycle("oauth");
    return;
  }
  stopBadgeTimer();
  badgeKind = null;
  applyIdleBadge();
}

function beginOauthWait() {
  oauthWaiting = true;
  if (badgeKind === "ok") return;
  if (activeFirmwareDownloads.size > 0) return;
  startBadgeCycle("oauth");
}

function endOauthWait() {
  oauthWaiting = false;
  if (badgeKind === "ok") return;
  refreshBusyBadge();
}

function showCapturedBadge() {
  oauthWaiting = false;
  if (okBadgeTimer) {
    clearTimeout(okBadgeTimer);
    okBadgeTimer = 0;
  }
  stopBadgeTimer();
  badgeKind = "ok";
  void chrome.action.setBadgeText({ text: "OK" });
  void chrome.action.setBadgeBackgroundColor({ color: BADGE_CYAN });
  okBadgeTimer = setTimeout(() => {
    okBadgeTimer = 0;
    if (badgeKind !== "ok") return;
    badgeKind = null;
    refreshBusyBadge();
  }, 2500);
}

function isFinalLenovoRedirect(url) {
  if (!url || typeof url !== "string") return false;
  const lower = url.toLowerCase();
  if (lower.startsWith("softwarefix://")) return true;
  if (
    lower.includes("accounts.google.com") ||
    lower.includes("thirdgooglecallback") ||
    lower.includes("thirdparty")
  ) {
    return false;
  }
  if (lower.includes("lenovoidsuccess")) return lower.includes("code=");
  if (lower.includes("/oauth2/callback")) return lower.includes("code=");
  return false;
}

function isPreferred(url) {
  return String(url).toLowerCase().startsWith("softwarefix://");
}

function isAppTab(url) {
  if (!url || typeof url !== "string") return false;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host === "localhost" || host === "127.0.0.1") return true;
    if (host === "pandonymus.com" || host.endsWith(".pandonymus.com")) {
      return parsed.pathname.includes("/pandaresuce");
    }
    return false;
  } catch {
    return false;
  }
}

function isAllowedFirmwareHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) return false;
  if (host === "rsddownload-secure.lenovo.com") return true;
  if (host === "download.lenovo.com" || host === "lsa.lenovo.com") return true;
  if (host === "lenovo.com" || host.endsWith(".lenovo.com")) return true;
  if (host === "motorola.com" || host.endsWith(".motorola.com")) return true;
  if (host.endsWith(".akamaihd.net") || host.endsWith(".akamaized.net")) return true;
  return host.endsWith(".amazonaws.com") || host.endsWith(".cloudfront.net");
}

function isAllowedFirmwareUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "https:" && isAllowedFirmwareHost(parsed.hostname);
  } catch {
    return false;
  }
}

function hostOf(rawUrl) {
  try {
    return new URL(rawUrl).hostname;
  } catch {
    return rawUrl;
  }
}

function cloneBytes(bytes) {
  const source = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const copy = new Uint8Array(source.byteLength);
  copy.set(source);
  return copy;
}

function asStandaloneBytes(bytes) {
  const source = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (source.byteOffset === 0 && source.byteLength === source.buffer.byteLength) {
    return source;
  }
  return cloneBytes(source);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function bytesToBase64(u8) {
  let binary = "";
  const step = 8192;
  for (let i = 0; i < u8.length; i += step) {
    binary += String.fromCharCode.apply(null, u8.subarray(i, i + step));
  }
  return btoa(binary);
}

async function sendToApp(url) {
  await chrome.storage.session.set({ lastRedirect: url, capturedAt: Date.now() });
  showCapturedBadge();

  const tabs = await chrome.tabs.query({});
  const appTabs = tabs.filter((tab) => isAppTab(tab.url));
  await Promise.all(
    appTabs.map((tab) =>
      tab.id
        ? chrome.tabs
            .sendMessage(tab.id, { type: "PANDONYMUS_LENOVO_OAUTH", url })
            .catch(() => undefined)
        : undefined,
    ),
  );
}

async function forwardRedirect(url) {
  if (!isFinalLenovoRedirect(url)) return;
  if (isPreferred(url)) {
    if (pendingTimer) clearTimeout(pendingTimer);
    pendingCode = null;
    pendingTimer = 0;
    await sendToApp(url);
    return;
  }
  pendingCode = url;
  if (pendingTimer) clearTimeout(pendingTimer);
  pendingTimer = setTimeout(() => {
    const fallback = pendingCode;
    pendingCode = null;
    pendingTimer = 0;
    if (fallback) void sendToApp(fallback);
  }, 2500);
}

function postFirmwareChunk(port, payload) {
  try {
    port.postMessage(payload);
    return true;
  } catch {
    return false;
  }
}

function postFirmwareLog(port, requestId, message) {
  postFirmwareChunk(port, { requestId, log: message });
}

function parseTotalBytes(response, fallback) {
  const range = response.headers.get("content-range");
  if (range) {
    const match = /\/(\d+)\s*$/.exec(range);
    if (match) {
      const total = Number(match[1]);
      if (Number.isFinite(total) && total > 0) return total;
    }
  }
  if (response.status === 206) return fallback;
  const length = Number(response.headers.get("content-length") || 0);
  if (Number.isFinite(length) && length > 0) return length;
  return fallback;
}

async function fetchUntilHeaders(url, init, controller) {
  const timeout = setTimeout(() => controller.abort(), FIRMWARE_FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

function postFirmwareData(job, bytes, offset, total) {
  const packed = asStandaloneBytes(bytes);
  const requestId = job.requestId;
  const port = job.port;
  const meta = { requestId, offset, total, byteLength: packed.byteLength };

  const sendBase64 = () => {
    const ok = postFirmwareChunk(port, {
      ...meta,
      encoding: "base64",
      dataB64: bytesToBase64(packed),
    });
    return ok ? "base64" : "failed";
  };

  if (job.useBase64) {
    return sendBase64();
  }

  try {
    const payload = { ...meta, data: packed.buffer };
    if (!job.sentFirst) {
      payload.encoding = "base64";
      payload.dataB64 = bytesToBase64(packed);
    }
    port.postMessage(payload);
    return job.sentFirst ? "arraybuffer" : "arraybuffer+base64";
  } catch {
    if (packed.byteLength > FIRST_FLUSH_BYTES) {
      return "too-large";
    }
    job.useBase64 = true;
    job.chunkBytes = BASE64_CHUNK_BYTES;
    return sendBase64();
  }
}

function waitForFirstAck(job) {
  if (job.firstAcked) return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      job.firstAcked = true;
      job.resolveFirstAck = null;
      resolve();
    }, FIRST_ACK_TIMEOUT_MS);
    job.resolveFirstAck = () => {
      clearTimeout(timer);
      job.firstAcked = true;
      job.resolveFirstAck = null;
      resolve();
    };
  });
}

async function waitForDrain(job) {
  while (!job.controller.signal.aborted && job.offset - job.ackedOffset > HIGH_WATER_BYTES) {
    await sleep(8);
  }
  if (job.controller.signal.aborted) {
    const err = new Error("Descarga cancelada.");
    err.name = "AbortError";
    throw err;
  }
}

async function consumeAndForward(job, response, startOffset, total, skipBytes = 0) {
  if (!response.body) {
    throw new Error("CDN no devolvio cuerpo (response.body vacio).");
  }

  const reader = response.body.getReader();
  const pending = [];
  let pendingBytes = 0;
  let skipLeft = skipBytes;
  let offset = startOffset;
  let firstReadLogged = job.sentFirst;
  let readStallTimer = 0;
  let readStalled = false;

  const clearReadStall = () => {
    if (readStallTimer) clearTimeout(readStallTimer);
    readStallTimer = 0;
  };

  const bumpReadStall = () => {
    clearReadStall();
    readStallTimer = setTimeout(() => {
      readStalled = true;
      job.controller.abort();
    }, FIRMWARE_READ_STALL_MS);
  };

  const takeBytes = (n) => {
    if (n <= 0) return new Uint8Array(0);
    if (pending.length === 1 && pending[0].byteLength === n) {
      const only = pending.pop();
      pendingBytes = 0;
      return only;
    }
    const out = new Uint8Array(n);
    let filled = 0;
    while (filled < n && pending.length) {
      const head = pending[0];
      const need = n - filled;
      if (head.byteLength <= need) {
        out.set(head, filled);
        filled += head.byteLength;
        pending.shift();
      } else {
        out.set(head.subarray(0, need), filled);
        pending[0] = head.subarray(need);
        filled += need;
      }
    }
    pendingBytes -= n;
    return out;
  };

  const sendSlice = async (slice) => {
    if (!slice.byteLength) return;
    let encoding = postFirmwareData(job, slice, offset + slice.byteLength, total);
    if (encoding === "too-large") {
      job.chunkBytes = Math.max(FIRST_FLUSH_BYTES, Math.floor(slice.byteLength / 2));
      const mid = Math.floor(slice.byteLength / 2) || slice.byteLength;
      await sendSlice(slice.subarray(0, mid));
      await sendSlice(slice.subarray(mid));
      return;
    }
    if (encoding === "failed") {
      throw new Error("No se pudo enviar el firmware al puerto de la extension.");
    }
    offset += slice.byteLength;
    job.offset = offset;
    const wasFirst = !job.sentFirst;
    if (wasFirst) {
      job.sentFirst = true;
      job.waitingFirst = false;
      job.chunkBytes = job.useBase64 ? BASE64_CHUNK_BYTES : STREAM_CHUNK_BYTES;
      postFirmwareLog(
        job.port,
        job.requestId,
        `Chunk forwarded (${slice.byteLength} B via ${encoding}, offset=${offset}, port open).`,
      );
      await waitForFirstAck(job);
    }
  };

  const flush = async (forceAll = false) => {
    if (!job.sentFirst && pendingBytes > 0) {
      const firstLen = Math.min(pendingBytes, FIRST_FLUSH_BYTES);
      await sendSlice(takeBytes(firstLen));
    }
    const size = job.chunkBytes || STREAM_CHUNK_BYTES;
    while (pendingBytes >= size) {
      await sendSlice(takeBytes(size));
      await waitForDrain(job);
    }
    if (forceAll && pendingBytes > 0) {
      await sendSlice(takeBytes(pendingBytes));
    }
  };

  try {
    bumpReadStall();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value?.byteLength) continue;
      bumpReadStall();
      let chunk = value;
      if (skipLeft > 0) {
        if (chunk.byteLength <= skipLeft) {
          skipLeft -= chunk.byteLength;
          continue;
        }
        chunk = chunk.subarray(skipLeft);
        skipLeft = 0;
      }
      if (!firstReadLogged) {
        firstReadLogged = true;
        postFirmwareLog(
          job.port,
          job.requestId,
          `First read ${chunk.byteLength} bytes from ${hostOf(response.url || "")}.`,
        );
      }
      pending.push(chunk);
      pendingBytes += chunk.byteLength;
      await flush(false);
    }
    await flush(true);
    return offset;
  } catch (error) {
    if (readStalled || (job.controller.signal.aborted && error instanceof Error && error.name === "AbortError")) {
      const err = new Error(
        readStalled
          ? "Sin datos del CDN de Lenovo en 60 s (descarga interrumpida)."
          : "Descarga cancelada.",
      );
      err.name = error instanceof Error ? error.name : "AbortError";
      throw err;
    }
    throw error;
  } finally {
    clearReadStall();
  }
}

async function streamByRanges(job, url, offset, total) {
  while (total == null || offset < total) {
    if (total != null && offset >= total) break;
    const end = total != null ? Math.min(offset + RANGE_FALLBACK_BYTES - 1, total - 1) : offset + RANGE_FALLBACK_BYTES - 1;
    if (total != null && end < offset) break;
    const part = await fetchUntilHeaders(url, {
      credentials: "omit",
      headers: { Range: `bytes=${offset}-${end}` },
      redirect: "follow",
    }, job.controller);
    if (!isAllowedFirmwareUrl(part.url)) {
      throw new Error(`Redirect de firmware no permitido: ${hostOf(part.url)}.`);
    }
    if (part.status === 416) {
      break;
    }
    if (part.status === 200) {
      if (!part.body) {
        throw new Error("El CDN dejo de aceptar Range a mitad de descarga.");
      }
      postFirmwareLog(
        job.port,
        job.requestId,
        "CDN ignoro Range; streaming GET completo y saltando bytes ya recibidos.",
      );
      const next = await consumeAndForward(job, part, offset, parseTotalBytes(part, total), offset);
      if (next <= offset) {
        throw new Error("El CDN no avanzo en el Range request.");
      }
      return next;
    }
    if (part.status !== 206 || !part.body) {
      throw new Error(`Descarga Lenovo fallo (HTTP ${part.status}) en ${hostOf(part.url)}.`);
    }
    const nextTotal = parseTotalBytes(part, total);
    const next = await consumeAndForward(job, part, offset, nextTotal);
    if (next <= offset) {
      throw new Error("El CDN no avanzo en el Range request.");
    }
    offset = next;
    total = nextTotal;
    if (total == null) break;
  }
  return offset;
}

async function streamRemainder(job, url, offset, total) {
  if (total != null && offset >= total) return offset;
  const rangeHeader = total != null ? `bytes=${offset}-${total - 1}` : `bytes=${offset}-`;
  postFirmwareLog(
    job.port,
    job.requestId,
    `Streaming GET ${rangeHeader} (${Math.round((job.chunkBytes || STREAM_CHUNK_BYTES) / 1024)} KiB chunks, ArrayBuffer).`,
  );
  const rest = await fetchUntilHeaders(url, {
    credentials: "omit",
    headers: { Range: rangeHeader },
    redirect: "follow",
  }, job.controller);
  if (!isAllowedFirmwareUrl(rest.url)) {
    throw new Error(`Redirect de firmware no permitido: ${hostOf(rest.url)}.`);
  }
  if (rest.status === 206 && rest.body) {
    return consumeAndForward(job, rest, offset, parseTotalBytes(rest, total));
  }
  if (rest.status === 200 && rest.body) {
    postFirmwareLog(
      job.port,
      job.requestId,
      "CDN ignoro Range en el resto; streaming GET y saltando bytes ya recibidos.",
    );
    return consumeAndForward(job, rest, offset, parseTotalBytes(rest, total), offset);
  }
  if (rest.status === 416) {
    return offset;
  }
  postFirmwareLog(
    job.port,
    job.requestId,
    `Remainder HTTP ${rest.status}; reintentando Range ${RANGE_FALLBACK_BYTES / (1024 * 1024)} MiB.`,
  );
  return streamByRanges(job, url, offset, total);
}

async function streamFirmwareDownload(port, requestId, url) {
  const controller = new AbortController();
  const alarmName = `pandonymus-fw-${requestId}`;
  const job = {
    requestId,
    port,
    controller,
    offset: 0,
    ackedOffset: 0,
    waitingFirst: true,
    sentFirst: false,
    firstAcked: false,
    resolveFirstAck: null,
    useBase64: false,
    chunkBytes: STREAM_CHUNK_BYTES,
    alarmName,
  };
  activeFirmwareDownloads.set(requestId, job);
  refreshBusyBadge();

  try {
    chrome.alarms.create(alarmName, { delayInMinutes: 0.2, periodInMinutes: 0.5 });
  } catch {
    /* alarms optional */
  }

  try {
    postFirmwareLog(port, requestId, `Probando streaming Range bytes=0-${RANGE_PROBE_END} → ${hostOf(url)}`);
    let probe;
    let rangeOk = false;
    try {
      probe = await fetchUntilHeaders(url, {
        credentials: "omit",
        headers: { Range: `bytes=0-${RANGE_PROBE_END}` },
        redirect: "follow",
      }, controller);
      rangeOk = probe.status === 206 && !!probe.body;
    } catch (error) {
      if (controller.signal.aborted) throw error;
      probe = null;
    }

    if (probe && !isAllowedFirmwareUrl(probe.url)) {
      postFirmwareChunk(port, {
        requestId,
        error: `Redirect de firmware no permitido: ${hostOf(probe.url)}.`,
        done: true,
      });
      return;
    }

    if (rangeOk && probe) {
      const total = parseTotalBytes(probe, undefined);
      postFirmwareChunk(port, { requestId, started: true, total, offset: 0, waitingFirst: true });
      postFirmwareLog(
        port,
        requestId,
        `CDN conectado via Range 206 (${total ?? "?"} bytes, ${hostOf(probe.url)}). Esperando primer bloque…`,
      );
      const offset = await consumeAndForward(job, probe, 0, total);
      const finalOffset = await streamRemainder(job, url, offset, total);
      postFirmwareChunk(port, { requestId, done: true, total: total ?? finalOffset, offset: finalOffset });
      return;
    }

    if (probe && probe.ok && probe.body && probe.status === 200) {
      const total = parseTotalBytes(probe, undefined);
      postFirmwareChunk(port, { requestId, started: true, total, offset: 0, waitingFirst: true });
      postFirmwareLog(
        port,
        requestId,
        `CDN ignoro Range (HTTP 200, ${total ?? "?"} bytes). Streaming getReader()…`,
      );
      const offset = await consumeAndForward(job, probe, 0, total);
      postFirmwareChunk(port, { requestId, done: true, total: total ?? offset, offset });
      return;
    }

    postFirmwareLog(
      port,
      requestId,
      probe
        ? `Range HTTP ${probe.status}; reintentando GET completo (sin Range).`
        : "Range fallo; reintentando GET completo (sin Range).",
    );

    const response = await fetchUntilHeaders(url, {
      credentials: "omit",
      redirect: "follow",
    }, controller);

    if (!isAllowedFirmwareUrl(response.url)) {
      postFirmwareChunk(port, {
        requestId,
        error: `Redirect de firmware no permitido: ${hostOf(response.url)}.`,
        done: true,
      });
      return;
    }

    if (!response.ok || !response.body) {
      postFirmwareChunk(port, {
        requestId,
        error: `Descarga Lenovo fallo (HTTP ${response.status}) en ${hostOf(response.url)}.`,
        done: true,
      });
      return;
    }

    const total = parseTotalBytes(response, undefined);
    postFirmwareChunk(port, { requestId, started: true, total, offset: 0, waitingFirst: true });
    postFirmwareLog(
      port,
      requestId,
      `CDN conectado (${total ?? "?"} bytes, ${hostOf(response.url)}). Leyendo primer bloque…`,
    );
    const offset = await consumeAndForward(job, response, 0, total);
    postFirmwareChunk(port, { requestId, done: true, total: total ?? offset, offset });
  } catch (error) {
    if (controller.signal.aborted) {
      const raw = error instanceof Error ? error.message : "";
      const message = /60 s/.test(raw) ? raw : "Descarga cancelada.";
      postFirmwareChunk(port, { requestId, error: message, done: true });
      return;
    }
    const message =
      error instanceof Error && error.name === "AbortError"
        ? "Tiempo de espera agotado al conectar con el CDN de Lenovo."
        : error instanceof Error
          ? error.message
          : String(error);
    postFirmwareChunk(port, { requestId, error: message, done: true });
  } finally {
    activeFirmwareDownloads.delete(requestId);
    try {
      chrome.alarms.clear(alarmName);
    } catch {
      /* ignore */
    }
    refreshBusyBadge();
  }
}

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onCommitted.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onErrorOccurred.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "PANDONYMUS_FIRMWARE_DOWNLOAD") return;

  port.onMessage.addListener((message) => {
    if (message?.type === "PANDONYMUS_FIRMWARE_HEARTBEAT") {
      const job = activeFirmwareDownloads.get(message.requestId);
      postFirmwareChunk(port, {
        requestId: message.requestId,
        heartbeat: true,
        offset: job?.offset ?? 0,
        waitingFirst: job ? job.waitingFirst : true,
        portOpen: true,
      });
      return;
    }
    if (message?.type === "PANDONYMUS_FIRMWARE_ACK") {
      const job = activeFirmwareDownloads.get(message.requestId);
      if (!job) return;
      if (typeof message.offset === "number" && Number.isFinite(message.offset)) {
        job.ackedOffset = Math.max(job.ackedOffset, message.offset);
      }
      if (message.binaryOk === false) {
        job.useBase64 = true;
        job.chunkBytes = BASE64_CHUNK_BYTES;
      }
      if (job.resolveFirstAck) job.resolveFirstAck();
      else job.firstAcked = true;
      return;
    }
    if (message?.type === "PANDONYMUS_FIRMWARE_USE_BASE64") {
      const job = activeFirmwareDownloads.get(message.requestId);
      if (job) {
        job.useBase64 = true;
        job.chunkBytes = BASE64_CHUNK_BYTES;
      }
      return;
    }
    if (message?.type !== "PANDONYMUS_FIRMWARE_START") return;
    const requestId = message.requestId;
    const url = message.url;
    if (!requestId || !url) {
      postFirmwareChunk(port, { requestId, error: "Solicitud de descarga invalida.", done: true });
      return;
    }
    if (!isAllowedFirmwareUrl(url)) {
      postFirmwareChunk(port, {
        requestId,
        error: `Host de firmware no permitido: ${hostOf(url)}. Solo CDN Lenovo/Motorola.`,
        done: true,
      });
      return;
    }
    void streamFirmwareDownload(port, requestId, url);
  });

  port.onDisconnect.addListener(() => {
    for (const [id, job] of activeFirmwareDownloads) {
      if (job.port !== port) continue;
      job.controller.abort();
      activeFirmwareDownloads.delete(id);
      try {
        chrome.alarms.clear(job.alarmName);
      } catch {
        /* ignore */
      }
    }
    refreshBusyBadge();
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!String(alarm?.name || "").startsWith("pandonymus-fw-")) return;
  /* Wake the MV3 worker while a firmware download is in flight. */
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "PANDONYMUS_CAPTURED_URL" && message.url) {
    void forwardRedirect(message.url).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "PANDONYMUS_GET_LAST") {
    chrome.storage.session.get(["lastRedirect", "capturedAt"]).then((stored) => {
      const age = Date.now() - (stored.capturedAt || 0);
      sendResponse({
        url: stored.lastRedirect && age < MAX_AGE_MS ? stored.lastRedirect : null,
      });
    });
    return true;
  }
  if (message?.type === "PANDONYMUS_PING") {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return true;
  }
  if (message?.type === "PANDONYMUS_LOGIN_WAIT") {
    beginOauthWait();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "PANDONYMUS_LOGIN_WAIT_STOP") {
    endOauthWait();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "PANDONYMUS_FIRMWARE_ABORT" && message.requestId) {
    const job = activeFirmwareDownloads.get(message.requestId);
    job?.controller.abort();
    activeFirmwareDownloads.delete(message.requestId);
    if (job?.alarmName) {
      try {
        chrome.alarms.clear(job.alarmName);
      } catch {
        /* ignore */
      }
    }
    refreshBusyBadge();
    sendResponse({ ok: true });
    return true;
  }
  return false;
});
