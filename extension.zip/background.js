const MAX_AGE_MS = 3 * 60 * 1000;
let pendingCode = null;
let pendingTimer = 0;
const pageFirmwareJobs = new Map();

const BADGE_TICK_MS = 400;
const BADGE_CYAN = "#00f5ff";
const BADGE_GREEN = "#39ff14";
let badgeTimer = 0;
let badgeKind = null;
let badgePhase = 0;
let oauthWaiting = false;
let okBadgeTimer = 0;

let offscreenPort = null;
let creatingOffscreen = null;

function stopBadgeTimer() {
  if (badgeTimer) {
    clearInterval(badgeTimer);
    badgeTimer = 0;
  }
}

function applyIdleBadge() {
  void chrome.action.setBadgeText({ text: "" });
}

function startBadgeCycle(kind) {
  if (badgeKind === kind && badgeTimer) return;
  stopBadgeTimer();
  badgeKind = kind;
  badgePhase = 0;
  const tick = () => {
    badgePhase = (badgePhase + 1) % 2;
    const on = badgePhase === 1;
    void chrome.action.setBadgeText({ text: on ? (kind === "download" ? "DL" : "ID") : "•••" });
    void chrome.action.setBadgeBackgroundColor({ color: on ? BADGE_CYAN : BADGE_GREEN });
  };
  tick();
  badgeTimer = setInterval(tick, BADGE_TICK_MS);
}

function refreshBusyBadge() {
  if (okBadgeTimer) {
    clearTimeout(okBadgeTimer);
    okBadgeTimer = 0;
  }
  if (pageFirmwareJobs.size > 0) {
    startBadgeCycle("download");
    return;
  }
  if (oauthWaiting) {
    startBadgeCycle("oauth");
    return;
  }
  stopBadgeTimer();
  badgeKind = null;
  applyIdleBadge();
}

function beginOauthWait() {
  oauthWaiting = true;
  if (badgeKind === "ok") return;
  if (pageFirmwareJobs.size > 0) return;
  startBadgeCycle("oauth");
}

function endOauthWait() {
  oauthWaiting = false;
  if (badgeKind === "ok") return;
  refreshBusyBadge();
}

function showCapturedBadge() {
  oauthWaiting = false;
  if (okBadgeTimer) {
    clearTimeout(okBadgeTimer);
    okBadgeTimer = 0;
  }
  stopBadgeTimer();
  badgeKind = "ok";
  void chrome.action.setBadgeText({ text: "OK" });
  void chrome.action.setBadgeBackgroundColor({ color: BADGE_CYAN });
  okBadgeTimer = setTimeout(() => {
    okBadgeTimer = 0;
    if (badgeKind !== "ok") return;
    badgeKind = null;
    refreshBusyBadge();
  }, 2500);
}

function isFinalLenovoRedirect(url) {
  if (!url || typeof url !== "string") return false;
  const lower = url.toLowerCase();
  if (lower.startsWith("softwarefix://")) return true;
  if (
    lower.includes("accounts.google.com") ||
    lower.includes("thirdgooglecallback") ||
    lower.includes("thirdparty")
  ) {
    return false;
  }
  if (lower.includes("lenovoidsuccess")) return lower.includes("code=");
  if (lower.includes("/oauth2/callback")) return lower.includes("code=");
  return false;
}

function isPreferred(url) {
  return String(url).toLowerCase().startsWith("softwarefix://");
}

function isAppTab(url) {
  if (!url || typeof url !== "string") return false;
  try {
    const parsed = new URL(url);
    const host = parsed.hostname.toLowerCase();
    if (host === "localhost" || host === "127.0.0.1") return true;
    if (host === "pandonymus.com" || host.endsWith(".pandonymus.com")) {
      return (
        parsed.pathname.includes("/pandarescue") ||
        parsed.pathname.includes("/pandaresuce")
      );
    }
    return false;
  } catch {
    return false;
  }
}

function hostOf(rawUrl) {
  try {
    return new URL(rawUrl).hostname;
  } catch {
    return rawUrl;
  }
}

function isAllowedFirmwareHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) return false;
  if (host === "rsddownload-secure.lenovo.com") return true;
  if (host === "download.lenovo.com" || host === "lsa.lenovo.com") return true;
  if (host === "lenovo.com" || host.endsWith(".lenovo.com")) return true;
  if (host === "motorola.com" || host.endsWith(".motorola.com")) return true;
  if (host.endsWith(".akamaihd.net") || host.endsWith(".akamaized.net")) return true;
  return host.endsWith(".amazonaws.com") || host.endsWith(".cloudfront.net");
}

function isAllowedFirmwareUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "https:" && isAllowedFirmwareHost(parsed.hostname);
  } catch {
    return false;
  }
}

async function sendToApp(url) {
  await chrome.storage.session.set({ lastRedirect: url, capturedAt: Date.now() });
  showCapturedBadge();

  const tabs = await chrome.tabs.query({});
  const appTabs = tabs.filter((tab) => isAppTab(tab.url));
  await Promise.all(
    appTabs.map((tab) =>
      tab.id
        ? chrome.tabs
            .sendMessage(tab.id, { type: "PANDONYMUS_LENOVO_OAUTH", url })
            .catch(() => undefined)
        : undefined,
    ),
  );
}

async function forwardRedirect(url) {
  if (!isFinalLenovoRedirect(url)) return;
  if (isPreferred(url)) {
    if (pendingTimer) clearTimeout(pendingTimer);
    pendingCode = null;
    pendingTimer = 0;
    await sendToApp(url);
    return;
  }
  pendingCode = url;
  if (pendingTimer) clearTimeout(pendingTimer);
  pendingTimer = setTimeout(() => {
    const fallback = pendingCode;
    pendingCode = null;
    pendingTimer = 0;
    if (fallback) void sendToApp(fallback);
  }, 2500);
}

function postFirmwareChunk(port, payload) {
  try {
    port.postMessage(payload);
    return true;
  } catch {
    return false;
  }
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function hasOffscreenDocument() {
  if (chrome.offscreen.hasDocument) {
    return chrome.offscreen.hasDocument();
  }
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ["OFFSCREEN_DOCUMENT"],
  });
  return contexts.length > 0;
}

async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) return;
  if (creatingOffscreen) {
    await creatingOffscreen;
    return;
  }
  creatingOffscreen = chrome.offscreen
    .createDocument({
      url: "offscreen.html",
      reasons: ["BLOBS"],
      justification:
        "Descarga de firmware Lenovo: el service worker MV3 se suspende durante fetch largos; el documento offscreen mantiene el stream vivo.",
    })
    .catch(async (error) => {
      const message = error instanceof Error ? error.message : String(error);
      if (/Only a single offscreen/i.test(message) || /already exists/i.test(message)) {
        return;
      }
      throw error;
    })
    .finally(() => {
      creatingOffscreen = null;
    });
  await creatingOffscreen;
}

async function ensureOffscreenPort() {
  await ensureOffscreenDocument();
  if (offscreenPort) return offscreenPort;
  const deadline = Date.now() + 1500;
  while (!offscreenPort && Date.now() < deadline) {
    await sleep(40);
  }
  if (offscreenPort) return offscreenPort;

  try {
    await chrome.offscreen.closeDocument();
  } catch {
    /* none */
  }
  offscreenPort = null;
  await ensureOffscreenDocument();
  const retryUntil = Date.now() + 4000;
  while (!offscreenPort && Date.now() < retryUntil) {
    await sleep(50);
  }
  if (!offscreenPort) {
    throw new Error("No se pudo iniciar el documento offscreen de descarga.");
  }
  return offscreenPort;
}

function postToOffscreen(payload) {
  if (!offscreenPort) return false;
  try {
    offscreenPort.postMessage(payload);
    return true;
  } catch {
    return false;
  }
}

function clearJobAlarm(job) {
  if (!job?.alarmName) return;
  try {
    chrome.alarms.clear(job.alarmName);
  } catch {
    /* ignore */
  }
}

function cleanupPageJob(requestId) {
  const job = pageFirmwareJobs.get(requestId);
  if (!job) return;
  pageFirmwareJobs.delete(requestId);
  clearJobAlarm(job);
  refreshBusyBadge();
  if (pageFirmwareJobs.size === 0) {
    try {
      chrome.alarms.clear("pandonymus-fw-keepalive");
    } catch {
      /* ignore */
    }
  }
}

function attachPageJob(port, requestId) {
  const alarmName = `pandonymus-fw-${requestId}`;
  const previous = pageFirmwareJobs.get(requestId);
  if (previous) clearJobAlarm(previous);
  pageFirmwareJobs.set(requestId, {
    port,
    requestId,
    offset: 0,
    alarmName,
  });
  refreshBusyBadge();
  try {
    chrome.alarms.create(alarmName, { delayInMinutes: 0.2, periodInMinutes: 0.4 });
    chrome.alarms.create("pandonymus-fw-keepalive", { delayInMinutes: 0.2, periodInMinutes: 0.4 });
  } catch {
    /* alarms optional */
  }
}

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onCommitted.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onErrorOccurred.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.runtime.onConnect.addListener((port) => {
  if (port.name === "PANDONYMUS_FIRMWARE_OFFSCREEN") {
    offscreenPort = port;
    port.onMessage.addListener((message) => {
      if (!message?.requestId) return;
      const job = pageFirmwareJobs.get(message.requestId);
      if (typeof message.offset === "number" && Number.isFinite(message.offset) && job) {
        job.offset = message.offset;
      }
      if (!job) return;
      if (!postFirmwareChunk(job.port, message)) return;
      if (message.done) cleanupPageJob(message.requestId);
    });
    port.onDisconnect.addListener(() => {
      if (offscreenPort === port) offscreenPort = null;
    });
    return;
  }

  if (port.name !== "PANDONYMUS_FIRMWARE_DOWNLOAD") return;

  port.onMessage.addListener((message) => {
    if (message?.type === "PANDONYMUS_FIRMWARE_HEARTBEAT") {
      const job = pageFirmwareJobs.get(message.requestId);
      if (job && typeof message.offset === "number") job.offset = message.offset;
      postToOffscreen({
        type: "PANDONYMUS_FIRMWARE_HEARTBEAT",
        requestId: message.requestId,
      });
      postFirmwareChunk(port, {
        requestId: message.requestId,
        heartbeat: true,
        offset: job?.offset ?? 0,
        waitingFirst: !job || job.offset === 0,
        portOpen: true,
      });
      return;
    }
    if (message?.type === "PANDONYMUS_FIRMWARE_ACK" || message?.type === "PANDONYMUS_FIRMWARE_USE_BASE64") {
      postToOffscreen(message);
      return;
    }
    if (message?.type !== "PANDONYMUS_FIRMWARE_START") return;
    const requestId = message.requestId;
    const url = message.url;
    if (!requestId || !url) {
      postFirmwareChunk(port, { requestId, error: "Solicitud de descarga invalida.", done: true });
      return;
    }
    if (!isAllowedFirmwareUrl(url)) {
      postFirmwareChunk(port, {
        requestId,
        error: `Host de firmware no permitido: ${hostOf(url)}. Solo CDN Lenovo/Motorola.`,
        done: true,
      });
      return;
    }
    attachPageJob(port, requestId);
    const job = pageFirmwareJobs.get(requestId);
    if (job && typeof message.resumeOffset === "number") job.offset = message.resumeOffset;
    void (async () => {
      try {
        await ensureOffscreenPort();
        if (!postToOffscreen({
          type: "PANDONYMUS_FIRMWARE_START",
          requestId,
          url,
          fileName: message.fileName,
          resumeOffset: message.resumeOffset || 0,
        })) {
          throw new Error("No se pudo hablar con el documento offscreen.");
        }
      } catch (error) {
        postFirmwareChunk(port, {
          requestId,
          error: error instanceof Error ? error.message : String(error),
          done: true,
        });
        cleanupPageJob(requestId);
      }
    })();
  });

  port.onDisconnect.addListener(() => {
    for (const [id, job] of pageFirmwareJobs) {
      if (job.port !== port) continue;
      postToOffscreen({ type: "PANDONYMUS_FIRMWARE_ABORT", requestId: id, reason: "page-disconnect" });
      cleanupPageJob(id);
    }
  });
});

chrome.alarms.onAlarm.addListener((alarm) => {
  if (!String(alarm?.name || "").startsWith("pandonymus-fw-")) return;
  if (pageFirmwareJobs.size === 0) return;
  postToOffscreen({ type: "PANDONYMUS_OFFSCREEN_PING" });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "PANDONYMUS_CAPTURED_URL" && message.url) {
    void forwardRedirect(message.url).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "PANDONYMUS_GET_LAST") {
    chrome.storage.session.get(["lastRedirect", "capturedAt"]).then((stored) => {
      const age = Date.now() - (stored.capturedAt || 0);
      sendResponse({
        url: stored.lastRedirect && age < MAX_AGE_MS ? stored.lastRedirect : null,
      });
    });
    return true;
  }
  if (message?.type === "PANDONYMUS_PING") {
    sendResponse({ ok: true, version: chrome.runtime.getManifest().version });
    return true;
  }
  if (message?.type === "PANDONYMUS_LOGIN_WAIT") {
    beginOauthWait();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "PANDONYMUS_LOGIN_WAIT_STOP") {
    endOauthWait();
    sendResponse({ ok: true });
    return true;
  }
  if (message?.type === "PANDONYMUS_OFFSCREEN_KEEPALIVE") {
    const job = pageFirmwareJobs.get(message.requestId);
    if (job && typeof message.offset === "number") job.offset = message.offset;
    sendResponse({ ok: true, offset: job?.offset ?? message.offset ?? 0 });
    return true;
  }
  if (message?.type === "PANDONYMUS_FIRMWARE_ABORT" && message.requestId) {
    postToOffscreen({ type: "PANDONYMUS_FIRMWARE_ABORT", requestId: message.requestId });
    cleanupPageJob(message.requestId);
    sendResponse({ ok: true });
    return true;
  }
  return false;
});
