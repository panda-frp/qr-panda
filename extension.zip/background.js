const MAX_AGE_MS = 3 * 60 * 1000;
let pendingCode = null;
let pendingTimer = 0;

function isFinalLenovoRedirect(url) {
  if (!url || typeof url !== "string") return false;
  const lower = url.toLowerCase();
  if (lower.startsWith("softwarefix://")) return true;
  if (
    lower.includes("accounts.google.com") ||
    lower.includes("thirdgooglecallback") ||
    lower.includes("thirdparty")
  ) {
    return false;
  }
  if (lower.includes("lenovoidsuccess")) return lower.includes("code=");
  if (lower.includes("/oauth2/callback")) return lower.includes("code=");
  return false;
}

function isPreferred(url) {
  return String(url).toLowerCase().startsWith("softwarefix://");
}

async function sendToApp(url) {
  await chrome.storage.session.set({ lastRedirect: url, capturedAt: Date.now() });
  const tabs = await chrome.tabs.query({
    url: ["http://localhost/*", "http://127.0.0.1/*"],
  });
  await Promise.all(
    tabs.map((tab) =>
      tab.id
        ? chrome.tabs
            .sendMessage(tab.id, { type: "PANDONYMUS_LENOVO_OAUTH", url })
            .catch(() => undefined)
        : undefined,
    ),
  );
}

async function forwardRedirect(url) {
  if (!isFinalLenovoRedirect(url)) return;
  if (isPreferred(url)) {
    if (pendingTimer) clearTimeout(pendingTimer);
    pendingCode = null;
    pendingTimer = 0;
    await sendToApp(url);
    return;
  }
  pendingCode = url;
  if (pendingTimer) clearTimeout(pendingTimer);
  pendingTimer = setTimeout(() => {
    const fallback = pendingCode;
    pendingCode = null;
    pendingTimer = 0;
    if (fallback) void sendToApp(fallback);
  }, 2500);
}

chrome.webNavigation.onBeforeNavigate.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onCommitted.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.webNavigation.onErrorOccurred.addListener((details) => {
  void forwardRedirect(details.url);
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "PANDONYMUS_CAPTURED_URL" && message.url) {
    void forwardRedirect(message.url).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === "PANDONYMUS_GET_LAST") {
    chrome.storage.session.get(["lastRedirect", "capturedAt"]).then((stored) => {
      const age = Date.now() - (stored.capturedAt || 0);
      sendResponse({
        url: stored.lastRedirect && age < MAX_AGE_MS ? stored.lastRedirect : null,
      });
    });
    return true;
  }
  return false;
});
