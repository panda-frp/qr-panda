function deliver(url) {
  if (!url) return;
  window.dispatchEvent(new CustomEvent("pandonymus-lenovo-oauth", { detail: { url } }));
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "PANDONYMUS_LENOVO_OAUTH" || !message.url) return;
  deliver(message.url);
});

window.addEventListener("pandonymus-request-oauth", () => {
  chrome.runtime.sendMessage({ type: "PANDONYMUS_GET_LAST" }, (response) => {
    deliver(response?.url);
  });
});
