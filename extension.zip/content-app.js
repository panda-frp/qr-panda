const firmwarePorts = new Map();

const MSG_PING = "PANDONYMUS_EXTENSION_PING";
const MSG_PONG = "PANDONYMUS_EXTENSION_PONG";
const MSG_FIRMWARE_REQUEST = "PANDONYMUS_FIRMWARE_REQUEST";
const MSG_FIRMWARE_CHUNK = "PANDONYMUS_FIRMWARE_CHUNK";
const MSG_FIRMWARE_ABORT = "PANDONYMUS_FIRMWARE_ABORT";
const MSG_LOG = "PANDONYMUS_EXTENSION_LOG";
const HEARTBEAT_MS = 10_000;

function postPong() {
  let version = "1.0.9";
  try {
    version = chrome.runtime.getManifest().version || version;
  } catch {
    /* keep default */
  }
  window.postMessage({ type: MSG_PONG, version }, window.location.origin);
}

function deliver(url) {
  if (!url) return;
  window.dispatchEvent(new CustomEvent("pandonymus-lenovo-oauth", { detail: { url } }));
}

function postExtensionLog(message) {
  window.postMessage({ type: MSG_LOG, message }, window.location.origin);
}

function isBinaryData(raw) {
  return raw instanceof ArrayBuffer || ArrayBuffer.isView(raw);
}

function chunkPayload(detail) {
  const payload = { ...detail };
  const raw = detail?.data;
  if (raw instanceof ArrayBuffer) {
    payload.data = raw;
  } else if (ArrayBuffer.isView(raw)) {
    const view = raw;
    payload.data =
      view.byteOffset === 0 && view.byteLength === view.buffer.byteLength
        ? view.buffer
        : view.buffer.slice(view.byteOffset, view.byteOffset + view.byteLength);
  } else {
    delete payload.data;
  }
  if (typeof detail?.dataB64 === "string") {
    payload.encoding = "base64";
    payload.dataB64 = detail.dataB64;
  } else {
    delete payload.dataB64;
  }
  return payload;
}

function dispatchFirmwareChunk(detail) {
  const payload = chunkPayload(detail);
  if (payload.data instanceof ArrayBuffer) {
    try {
      window.postMessage({ type: MSG_FIRMWARE_CHUNK, detail: payload }, window.location.origin, [payload.data]);
      return;
    } catch {
      /* transfer not available; clone below if the buffer is still usable */
    }
  }
  window.postMessage({ type: MSG_FIRMWARE_CHUNK, detail: payload }, window.location.origin);
}

function closeFirmwarePort(requestId) {
  const port = firmwarePorts.get(requestId);
  if (!port) return;
  firmwarePorts.delete(requestId);
  if (port._heartbeat) {
    clearInterval(port._heartbeat);
    port._heartbeat = 0;
  }
  try {
    port.disconnect();
  } catch {
    /* already closed */
  }
}

function startFirmwareDownload(detail) {
  const requestId = detail?.requestId;
  const url = detail?.url;
  const fileName = detail?.fileName;
  if (!requestId || !url) {
    dispatchFirmwareChunk({
      requestId: requestId || "unknown",
      error: "Solicitud invalida (falta requestId o url).",
      done: true,
    });
    return;
  }

  if (firmwarePorts.has(requestId)) {
    postExtensionLog(`Descarga ${requestId.slice(0, 8)} ya en curso (ignorando duplicado).`);
    return;
  }

  postExtensionLog(`Conectando con background para ${new URL(url).hostname}…`);

  let port;
  try {
    port = chrome.runtime.connect({ name: "PANDONYMUS_FIRMWARE_DOWNLOAD" });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    dispatchFirmwareChunk({
      requestId,
      error: `No se pudo conectar con la extension: ${message}`,
      done: true,
    });
    return;
  }

  if (chrome.runtime.lastError) {
    dispatchFirmwareChunk({
      requestId,
      error: `No se pudo conectar con la extension: ${chrome.runtime.lastError.message}`,
      done: true,
    });
    return;
  }

  firmwarePorts.set(requestId, port);
  let finished = false;

  const finishWithError = (message) => {
    if (finished) return;
    finished = true;
    dispatchFirmwareChunk({ requestId, error: message, done: true });
    closeFirmwarePort(requestId);
  };

  port._heartbeat = setInterval(() => {
    if (finished) return;
    try {
      port.postMessage({ type: "PANDONYMUS_FIRMWARE_HEARTBEAT", requestId });
    } catch {
      finishWithError("Conexion con la extension perdida durante heartbeat.");
    }
  }, HEARTBEAT_MS);

  port.onMessage.addListener((message) => {
    if (message?.requestId !== requestId) return;

    if (typeof message.log === "string") {
      postExtensionLog(message.log);
    }

    if (message.heartbeat) {
      if (message.waitingFirst) {
        postExtensionLog("esperando primer bloque… (port still open)");
        dispatchFirmwareChunk(message);
      }
      return;
    }

    if (message.started) {
      postExtensionLog(
        message.total
          ? `Background: CDN conectado (${message.total} bytes).`
          : "Background: CDN conectado.",
      );
    }

    const hasBinary = isBinaryData(message.data);
    const hasB64 = typeof message.dataB64 === "string" && message.dataB64.length > 0;
    if (message.byteLength > 0 && !hasBinary && !hasB64) {
      postExtensionLog("ArrayBuffer no sobrevivio el puerto; cambiando a base64.");
      try {
        port.postMessage({ type: "PANDONYMUS_FIRMWARE_USE_BASE64", requestId });
      } catch {
        /* port closed */
      }
    }
    dispatchFirmwareChunk(message);
    if (hasBinary || hasB64) {
      try {
        port.postMessage({
          type: "PANDONYMUS_FIRMWARE_ACK",
          requestId,
          offset: message.offset || 0,
          binaryOk: hasBinary,
        });
      } catch {
        /* port closed */
      }
    }
    if (message.done || message.error) {
      finished = true;
      closeFirmwarePort(requestId);
    }
  });

  port.onDisconnect.addListener(() => {
    firmwarePorts.delete(requestId);
    if (port._heartbeat) {
      clearInterval(port._heartbeat);
      port._heartbeat = 0;
    }
    if (finished) return;
    const reason = chrome.runtime.lastError?.message;
    finishWithError(
      reason
        ? `Conexion con la extension perdida: ${reason}`
        : "Conexion con la extension perdida. Recarga la pagina (F5) e intenta de nuevo.",
    );
  });

  port.postMessage({
    type: "PANDONYMUS_FIRMWARE_START",
    requestId,
    url,
    fileName,
  });
  postExtensionLog("Solicitud enviada al service worker.");
}

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "PANDONYMUS_LENOVO_OAUTH" || !message.url) return;
  deliver(message.url);
});

window.addEventListener("pandonymus-request-oauth", () => {
  chrome.runtime.sendMessage({ type: "PANDONYMUS_LOGIN_WAIT" }, () => {
    void chrome.runtime.lastError;
  });
  chrome.runtime.sendMessage({ type: "PANDONYMUS_GET_LAST" }, (response) => {
    if (chrome.runtime.lastError) return;
    deliver(response?.url);
  });
});

window.addEventListener("pandonymus-login-wait-stop", () => {
  chrome.runtime.sendMessage({ type: "PANDONYMUS_LOGIN_WAIT_STOP" }, () => {
    void chrome.runtime.lastError;
  });
});

window.addEventListener("pandonymus-request-firmware-download", (event) => {
  startFirmwareDownload(event.detail || {});
});

window.addEventListener("pandonymus-extension-ping", () => {
  postPong();
});

window.addEventListener("message", (event) => {
  if (event.source !== window || event.origin !== window.location.origin) return;
  const data = event.data;
  if (!data || typeof data.type !== "string") return;

  if (data.type === MSG_PING) {
    postPong();
    return;
  }
  if (data.type === MSG_FIRMWARE_REQUEST) {
    startFirmwareDownload(data.detail || {});
    return;
  }
  if (data.type === MSG_FIRMWARE_ABORT) {
    const requestId = data.detail?.requestId;
    if (!requestId) return;
    closeFirmwarePort(requestId);
    chrome.runtime.sendMessage({ type: "PANDONYMUS_FIRMWARE_ABORT", requestId }, () => {
      void chrome.runtime.lastError;
    });
  }
});

window.addEventListener("pandonymus-abort-firmware-download", (event) => {
  const requestId = event.detail?.requestId;
  if (!requestId) return;
  closeFirmwarePort(requestId);
  chrome.runtime.sendMessage({ type: "PANDONYMUS_FIRMWARE_ABORT", requestId }, () => {
    void chrome.runtime.lastError;
  });
});

document.documentElement.dataset.pandonymusExt = "1";
window.dispatchEvent(new CustomEvent("pandonymus-extension-ready"));
