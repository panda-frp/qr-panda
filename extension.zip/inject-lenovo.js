(() => {
  const report = (url) => {
    if (typeof url !== "string") return;
    const lower = url.toLowerCase();
    const isFinal =
      lower.startsWith("softwarefix://") ||
      (lower.includes("lenovoidsuccess") && url.includes("code=")) ||
      (lower.includes("/oauth2/callback") && url.includes("code="));
    if (!isFinal) return;
    window.postMessage({ type: "PANDONYMUS_CAPTURED_URL", url }, "*");
  };

  if (
    location.search &&
    location.search.includes("code=") &&
    /lenovoidsuccess|oauth2\/callback/i.test(location.href)
  ) {
    report(location.href);
  }

  const assign = window.location.assign.bind(window.location);
  window.location.assign = (url) => {
    report(String(url));
    return assign(url);
  };
  const replace = window.location.replace.bind(window.location);
  window.location.replace = (url) => {
    report(String(url));
    return replace(url);
  };
  if (window.open) {
    const open = window.open.bind(window);
    window.open = (url, ...rest) => {
      if (url) report(String(url));
      return open(url, ...rest);
    };
  }

  document.addEventListener(
    "click",
    (event) => {
      const link = event.target instanceof Element ? event.target.closest("a[href]") : null;
      if (link) report(link.href);
    },
    true,
  );
})();
