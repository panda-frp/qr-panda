window.addEventListener("message", (event) => {
  if (event.source !== window) return;
  const data = event.data;
  if (!data || data.type !== "PANDONYMUS_CAPTURED_URL" || !data.url) return;
  chrome.runtime.sendMessage({ type: "PANDONYMUS_CAPTURED_URL", url: data.url }).catch(() => undefined);
});
