const FIRST_FLUSH_BYTES = 64 * 1024;
const STREAM_CHUNK_BYTES = 256 * 1024;
const STREAM_CHUNK_MAX = 512 * 1024;
const STREAM_CHUNK_MIN = 64 * 1024;
const BASE64_CHUNK_BYTES = 256 * 1024;
const RANGE_PROBE_END = FIRST_FLUSH_BYTES - 1;
const RANGE_FALLBACK_BYTES = 8 * 1024 * 1024;
const HIGH_WATER_BYTES = 16 * 1024 * 1024;
const FIRST_ACK_TIMEOUT_MS = 2_000;
const FIRMWARE_FETCH_TIMEOUT_MS = 60_000;
const FIRMWARE_READ_STALL_MS = 60_000;
const HEARTBEAT_MS = 10_000;

const activeFirmwareDownloads = new Map();
let swPort = null;
let reconnectTimer = 0;

function isAllowedFirmwareHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host) return false;
  if (host === "rsddownload-secure.lenovo.com") return true;
  if (host === "download.lenovo.com" || host === "lsa.lenovo.com") return true;
  if (host === "lenovo.com" || host.endsWith(".lenovo.com")) return true;
  if (host === "motorola.com" || host.endsWith(".motorola.com")) return true;
  if (host.endsWith(".akamaihd.net") || host.endsWith(".akamaized.net")) return true;
  return host.endsWith(".amazonaws.com") || host.endsWith(".cloudfront.net");
}

function isAllowedFirmwareUrl(rawUrl) {
  if (!rawUrl || typeof rawUrl !== "string") return false;
  try {
    const parsed = new URL(rawUrl);
    return parsed.protocol === "https:" && isAllowedFirmwareHost(parsed.hostname);
  } catch {
    return false;
  }
}

function hostOf(rawUrl) {
  try {
    return new URL(rawUrl).hostname;
  } catch {
    return rawUrl;
  }
}

function cloneBytes(bytes) {
  const source = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const copy = new Uint8Array(source.byteLength);
  copy.set(source);
  return copy;
}

function asStandaloneBytes(bytes) {
  const source = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  if (source.byteOffset === 0 && source.byteLength === source.buffer.byteLength) {
    return source;
  }
  return cloneBytes(source);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function bytesToBase64(u8) {
  let binary = "";
  const step = 8192;
  for (let i = 0; i < u8.length; i += step) {
    binary += String.fromCharCode.apply(null, u8.subarray(i, i + step));
  }
  return btoa(binary);
}

function postFirmwareChunk(payload) {
  if (!swPort) return false;
  try {
    swPort.postMessage(payload);
    return true;
  } catch {
    return false;
  }
}

function postFirmwareLog(requestId, message) {
  postFirmwareChunk({ requestId, log: message });
}

function parseTotalBytes(response, fallback) {
  const range = response.headers.get("content-range");
  if (range) {
    const match = /\/(\d+)\s*$/.exec(range);
    if (match) {
      const total = Number(match[1]);
      if (Number.isFinite(total) && total > 0) return total;
    }
  }
  if (response.status === 206) return fallback;
  const length = Number(response.headers.get("content-length") || 0);
  if (Number.isFinite(length) && length > 0) return length;
  return fallback;
}

async function fetchUntilHeaders(url, init, controller) {
  const timeout = setTimeout(() => controller.abort(), FIRMWARE_FETCH_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timeout);
  }
}

function shrinkChunkBytes(job, fromBytes) {
  const next = Math.max(STREAM_CHUNK_MIN, Math.floor((fromBytes || job.chunkBytes) / 2));
  job.chunkBytes = job.useBase64 ? Math.min(next, BASE64_CHUNK_BYTES) : next;
  return job.chunkBytes;
}

function postFirmwareData(job, bytes, offset, total) {
  const packed = asStandaloneBytes(bytes);
  const requestId = job.requestId;
  const meta = { requestId, offset, total, byteLength: packed.byteLength };

  const sendBase64 = () => {
    const ok = postFirmwareChunk({
      ...meta,
      encoding: "base64",
      dataB64: bytesToBase64(packed),
    });
    return ok ? "base64" : "failed";
  };

  if (job.useBase64) {
    return sendBase64();
  }

  if (packed.byteLength > STREAM_CHUNK_MAX) {
    return "too-large";
  }

  try {
    const payload = { ...meta, data: packed.buffer };
    if (!job.sentFirst) {
      payload.encoding = "base64";
      payload.dataB64 = bytesToBase64(packed);
    }
    if (!swPort) return "failed";
    swPort.postMessage(payload);
    return job.sentFirst ? "arraybuffer" : "arraybuffer+base64";
  } catch {
    if (packed.byteLength > STREAM_CHUNK_MIN) {
      return "too-large";
    }
    job.useBase64 = true;
    job.chunkBytes = Math.min(BASE64_CHUNK_BYTES, STREAM_CHUNK_BYTES);
    return sendBase64();
  }
}

function waitForFirstAck(job) {
  if (job.firstAcked) return Promise.resolve();
  return new Promise((resolve) => {
    const timer = setTimeout(() => {
      job.firstAcked = true;
      job.resolveFirstAck = null;
      resolve();
    }, FIRST_ACK_TIMEOUT_MS);
    job.resolveFirstAck = () => {
      clearTimeout(timer);
      job.firstAcked = true;
      job.resolveFirstAck = null;
      resolve();
    };
  });
}

async function waitForDrain(job) {
  while (!job.controller.signal.aborted && job.offset - job.ackedOffset > HIGH_WATER_BYTES) {
    await sleep(8);
  }
  if (job.controller.signal.aborted) {
    const err = new Error("Descarga cancelada.");
    err.name = "AbortError";
    throw err;
  }
}

async function consumeAndForward(job, response, startOffset, total, skipBytes = 0) {
  if (!response.body) {
    throw new Error("CDN no devolvio cuerpo (response.body vacio).");
  }

  const reader = response.body.getReader();
  const pending = [];
  let pendingBytes = 0;
  let skipLeft = skipBytes;
  let offset = startOffset;
  let firstReadLogged = job.sentFirst;
  let readStallTimer = 0;
  let readStalled = false;

  const clearReadStall = () => {
    if (readStallTimer) clearTimeout(readStallTimer);
    readStallTimer = 0;
  };

  const bumpReadStall = () => {
    clearReadStall();
    readStallTimer = setTimeout(() => {
      readStalled = true;
      job.controller.abort();
    }, FIRMWARE_READ_STALL_MS);
  };

  const takeBytes = (n) => {
    if (n <= 0) return new Uint8Array(0);
    if (pending.length === 1 && pending[0].byteLength === n) {
      const only = pending.pop();
      pendingBytes = 0;
      return only;
    }
    const out = new Uint8Array(n);
    let filled = 0;
    while (filled < n && pending.length) {
      const head = pending[0];
      const need = n - filled;
      if (head.byteLength <= need) {
        out.set(head, filled);
        filled += head.byteLength;
        pending.shift();
      } else {
        out.set(head.subarray(0, need), filled);
        pending[0] = head.subarray(need);
        filled += need;
      }
    }
    pendingBytes -= n;
    return out;
  };

  const sendSlice = async (slice) => {
    if (!slice.byteLength) return;
    let encoding = postFirmwareData(job, slice, offset + slice.byteLength, total);
    if (encoding === "too-large") {
      const nextSize = shrinkChunkBytes(job, slice.byteLength);
      postFirmwareLog(
        job.requestId,
        `Puerto rechazo ${slice.byteLength} B; bajando chunks a ${Math.round(nextSize / 1024)} KiB.`,
      );
      const mid = Math.floor(slice.byteLength / 2) || slice.byteLength;
      await sendSlice(slice.subarray(0, mid));
      await sendSlice(slice.subarray(mid));
      return;
    }
    if (encoding === "failed") {
      throw new Error("No se pudo enviar el firmware al puerto de la extension.");
    }
    offset += slice.byteLength;
    job.offset = offset;
    const wasFirst = !job.sentFirst;
    if (wasFirst) {
      job.sentFirst = true;
      job.waitingFirst = false;
      job.chunkBytes = job.useBase64
        ? Math.min(BASE64_CHUNK_BYTES, STREAM_CHUNK_BYTES)
        : STREAM_CHUNK_BYTES;
      postFirmwareLog(
        job.requestId,
        `Chunk forwarded (${slice.byteLength} B via ${encoding}, offset=${offset}, offscreen).`,
      );
      await waitForFirstAck(job);
    }
  };

  const flush = async (forceAll = false) => {
    if (!job.sentFirst && pendingBytes > 0) {
      const firstLen = Math.min(pendingBytes, FIRST_FLUSH_BYTES);
      await sendSlice(takeBytes(firstLen));
    }
    const size = Math.min(
      Math.max(job.chunkBytes || STREAM_CHUNK_BYTES, STREAM_CHUNK_MIN),
      STREAM_CHUNK_MAX,
    );
    while (pendingBytes >= size) {
      await sendSlice(takeBytes(size));
      await waitForDrain(job);
    }
    if (forceAll && pendingBytes > 0) {
      await sendSlice(takeBytes(pendingBytes));
    }
  };

  try {
    bumpReadStall();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!value?.byteLength) continue;
      bumpReadStall();
      let chunk = value;
      if (skipLeft > 0) {
        if (chunk.byteLength <= skipLeft) {
          skipLeft -= chunk.byteLength;
          continue;
        }
        chunk = chunk.subarray(skipLeft);
        skipLeft = 0;
      }
      if (!firstReadLogged) {
        firstReadLogged = true;
        postFirmwareLog(
          job.requestId,
          `First read ${chunk.byteLength} bytes from ${hostOf(response.url || "")}.`,
        );
      }
      pending.push(chunk);
      pendingBytes += chunk.byteLength;
      await flush(false);
    }
    await flush(true);
    return offset;
  } catch (error) {
    if (readStalled || (job.controller.signal.aborted && error instanceof Error && error.name === "AbortError")) {
      const err = new Error(
        readStalled
          ? "Sin datos del CDN de Lenovo en 60 s (descarga interrumpida)."
          : "Descarga cancelada.",
      );
      err.name = error instanceof Error ? error.name : "AbortError";
      throw err;
    }
    throw error;
  } finally {
    clearReadStall();
  }
}

async function streamByRanges(job, url, offset, total) {
  while (total == null || offset < total) {
    if (total != null && offset >= total) break;
    const end = total != null ? Math.min(offset + RANGE_FALLBACK_BYTES - 1, total - 1) : offset + RANGE_FALLBACK_BYTES - 1;
    if (total != null && end < offset) break;
    const part = await fetchUntilHeaders(url, {
      credentials: "omit",
      headers: { Range: `bytes=${offset}-${end}` },
      redirect: "follow",
    }, job.controller);
    if (!isAllowedFirmwareUrl(part.url)) {
      throw new Error(`Redirect de firmware no permitido: ${hostOf(part.url)}.`);
    }
    if (part.status === 416) {
      break;
    }
    if (part.status === 200) {
      if (offset > 0) {
        throw new Error(
          "El CDN ignoro Range a mitad de descarga. El progreso queda en Cache; reintenta para reanudar.",
        );
      }
      if (!part.body) {
        throw new Error("El CDN dejo de aceptar Range a mitad de descarga.");
      }
      postFirmwareLog(
        job.requestId,
        "CDN ignoro Range; streaming GET completo y saltando bytes ya recibidos.",
      );
      const next = await consumeAndForward(job, part, offset, parseTotalBytes(part, total), offset);
      if (next <= offset) {
        throw new Error("El CDN no avanzo en el Range request.");
      }
      return next;
    }
    if (part.status !== 206 || !part.body) {
      throw new Error(`Descarga Lenovo fallo (HTTP ${part.status}) en ${hostOf(part.url)}.`);
    }
    const nextTotal = parseTotalBytes(part, total);
    const next = await consumeAndForward(job, part, offset, nextTotal);
    if (next <= offset) {
      throw new Error("El CDN no avanzo en el Range request.");
    }
    offset = next;
    total = nextTotal;
    if (total == null) break;
  }
  return offset;
}

async function streamRemainder(job, url, offset, total) {
  if (total != null && offset >= total) return offset;
  const rangeHeader = total != null ? `bytes=${offset}-${total - 1}` : `bytes=${offset}-`;
  const chunkKiB = Math.round((job.chunkBytes || STREAM_CHUNK_BYTES) / 1024);
  postFirmwareLog(
    job.requestId,
    `Streaming GET ${rangeHeader} (${chunkKiB} KiB chunks, ArrayBuffer, offscreen).`,
  );
  const rest = await fetchUntilHeaders(url, {
    credentials: "omit",
    headers: { Range: rangeHeader },
    redirect: "follow",
  }, job.controller);
  if (!isAllowedFirmwareUrl(rest.url)) {
    throw new Error(`Redirect de firmware no permitido: ${hostOf(rest.url)}.`);
  }
  if (rest.status === 206 && rest.body) {
    return consumeAndForward(job, rest, offset, parseTotalBytes(rest, total));
  }
  if (rest.status === 200 && rest.body) {
    if (offset > 0) {
      try {
        rest.body.cancel();
      } catch {
        /* ignore */
      }
      throw new Error(
        "El CDN ignoro Range en el resto. El progreso queda en Cache; reintenta para reanudar.",
      );
    }
    postFirmwareLog(
      job.requestId,
      "CDN ignoro Range en el resto; streaming GET y saltando bytes ya recibidos.",
    );
    return consumeAndForward(job, rest, offset, parseTotalBytes(rest, total), offset);
  }
  if (rest.status === 416) {
    return offset;
  }
  postFirmwareLog(
    job.requestId,
    `Remainder HTTP ${rest.status}; reintentando Range ${RANGE_FALLBACK_BYTES / (1024 * 1024)} MiB.`,
  );
  return streamByRanges(job, url, offset, total);
}

function startJobHeartbeat(job) {
  if (job.heartbeatTimer) return;
  job.heartbeatTimer = setInterval(() => {
    postFirmwareChunk({
      requestId: job.requestId,
      heartbeat: true,
      offset: job.offset,
      waitingFirst: job.waitingFirst,
      portOpen: !!swPort,
    });
    try {
      chrome.runtime.sendMessage({
        type: "PANDONYMUS_OFFSCREEN_KEEPALIVE",
        requestId: job.requestId,
        offset: job.offset,
      }, () => {
        void chrome.runtime.lastError;
      });
    } catch {
      /* SW may be restarting */
    }
  }, HEARTBEAT_MS);
}

function stopJobHeartbeat(job) {
  if (!job?.heartbeatTimer) return;
  clearInterval(job.heartbeatTimer);
  job.heartbeatTimer = 0;
}

function finishJob(requestId) {
  const job = activeFirmwareDownloads.get(requestId);
  if (!job) return;
  stopJobHeartbeat(job);
  activeFirmwareDownloads.delete(requestId);
}

async function streamFirmwareDownload(requestId, url, resumeOffset) {
  const startAt = Math.max(0, Number(resumeOffset) || 0);
  const controller = new AbortController();
  const job = {
    requestId,
    controller,
    offset: startAt,
    ackedOffset: startAt,
    waitingFirst: true,
    sentFirst: false,
    firstAcked: false,
    resolveFirstAck: null,
    useBase64: false,
    chunkBytes: STREAM_CHUNK_BYTES,
    heartbeatTimer: 0,
  };
  const previous = activeFirmwareDownloads.get(requestId);
  if (previous) {
    previous.controller.abort();
    stopJobHeartbeat(previous);
  }
  activeFirmwareDownloads.set(requestId, job);
  startJobHeartbeat(job);

  try {
    if (startAt > 0) {
      postFirmwareLog(
        requestId,
        `Reanudando desde byte ${startAt}. Range bytes=${startAt}- → ${hostOf(url)}`,
      );
      const probe = await fetchUntilHeaders(url, {
        credentials: "omit",
        headers: { Range: `bytes=${startAt}-` },
        redirect: "follow",
      }, controller);

      if (!isAllowedFirmwareUrl(probe.url)) {
        postFirmwareChunk({
          requestId,
          error: `Redirect de firmware no permitido: ${hostOf(probe.url)}.`,
          done: true,
        });
        return;
      }

      if (probe.status === 206 && probe.body) {
        const total = parseTotalBytes(probe, undefined);
        postFirmwareChunk({
          requestId,
          started: true,
          resumed: true,
          total,
          offset: startAt,
          waitingFirst: true,
        });
        postFirmwareLog(
          requestId,
          `CDN reanudo via Range 206 (${total ?? "?"} bytes, offset=${startAt}, ${hostOf(probe.url)}).`,
        );
        const offset = await consumeAndForward(job, probe, startAt, total);
        const finalOffset = await streamRemainder(job, url, offset, total);
        postFirmwareChunk({ requestId, done: true, total: total ?? finalOffset, offset: finalOffset });
        return;
      }

      if (probe.status === 200) {
        try {
          probe.body?.cancel();
        } catch {
          /* ignore */
        }
        throw new Error(
          "El CDN no acepto Range para reanudar. El progreso queda en Cache; reintenta para continuar.",
        );
      }

      if (probe.status === 416) {
        postFirmwareChunk({ requestId, done: true, offset: startAt, total: startAt });
        return;
      }

      postFirmwareLog(
        requestId,
        `Reanudacion HTTP ${probe.status}; intentando GET Range bytes=${startAt}-.`,
      );
      postFirmwareChunk({
        requestId,
        started: true,
        resumed: true,
        offset: startAt,
        waitingFirst: true,
      });
      const finalOffset = await streamRemainder(job, url, startAt, undefined);
      postFirmwareChunk({ requestId, done: true, total: finalOffset, offset: finalOffset });
      return;
    }

    postFirmwareLog(requestId, `Probando streaming Range bytes=0-${RANGE_PROBE_END} → ${hostOf(url)}`);
    let probe;
    let rangeOk = false;
    try {
      probe = await fetchUntilHeaders(url, {
        credentials: "omit",
        headers: { Range: `bytes=0-${RANGE_PROBE_END}` },
        redirect: "follow",
      }, controller);
      rangeOk = probe.status === 206 && !!probe.body;
    } catch (error) {
      if (controller.signal.aborted) throw error;
      probe = null;
    }

    if (probe && !isAllowedFirmwareUrl(probe.url)) {
      postFirmwareChunk({
        requestId,
        error: `Redirect de firmware no permitido: ${hostOf(probe.url)}.`,
        done: true,
      });
      return;
    }

    if (rangeOk && probe) {
      const total = parseTotalBytes(probe, undefined);
      postFirmwareChunk({ requestId, started: true, total, offset: 0, waitingFirst: true });
      postFirmwareLog(
        requestId,
        `CDN conectado via Range 206 (${total ?? "?"} bytes, ${hostOf(probe.url)}). Esperando primer bloque…`,
      );
      const offset = await consumeAndForward(job, probe, 0, total);
      const finalOffset = await streamRemainder(job, url, offset, total);
      postFirmwareChunk({ requestId, done: true, total: total ?? finalOffset, offset: finalOffset });
      return;
    }

    if (probe && probe.ok && probe.body && probe.status === 200) {
      const total = parseTotalBytes(probe, undefined);
      postFirmwareChunk({ requestId, started: true, total, offset: 0, waitingFirst: true });
      postFirmwareLog(
        requestId,
        `CDN ignoro Range (HTTP 200, ${total ?? "?"} bytes). Streaming getReader()…`,
      );
      const offset = await consumeAndForward(job, probe, 0, total);
      postFirmwareChunk({ requestId, done: true, total: total ?? offset, offset });
      return;
    }

    postFirmwareLog(
      requestId,
      probe
        ? `Range HTTP ${probe.status}; reintentando GET completo (sin Range).`
        : "Range fallo; reintentando GET completo (sin Range).",
    );

    const response = await fetchUntilHeaders(url, {
      credentials: "omit",
      redirect: "follow",
    }, controller);

    if (!isAllowedFirmwareUrl(response.url)) {
      postFirmwareChunk({
        requestId,
        error: `Redirect de firmware no permitido: ${hostOf(response.url)}.`,
        done: true,
      });
      return;
    }

    if (!response.ok || !response.body) {
      postFirmwareChunk({
        requestId,
        error: `Descarga Lenovo fallo (HTTP ${response.status}) en ${hostOf(response.url)}.`,
        done: true,
      });
      return;
    }

    const total = parseTotalBytes(response, undefined);
    postFirmwareChunk({ requestId, started: true, total, offset: 0, waitingFirst: true });
    postFirmwareLog(
      requestId,
      `CDN conectado (${total ?? "?"} bytes, ${hostOf(response.url)}). Leyendo primer bloque…`,
    );
    const offset = await consumeAndForward(job, response, 0, total);
    postFirmwareChunk({ requestId, done: true, total: total ?? offset, offset });
  } catch (error) {
    if (controller.signal.aborted) {
      const raw = error instanceof Error ? error.message : "";
      if (/60 s/.test(raw)) {
        postFirmwareChunk({ requestId, error: raw, done: true });
      }
      return;
    }
    const message =
      error instanceof Error && error.name === "AbortError"
        ? "Tiempo de espera agotado al conectar con el CDN de Lenovo."
        : error instanceof Error
          ? error.message
          : String(error);
    postFirmwareChunk({ requestId, error: message, done: true });
  } finally {
    finishJob(requestId);
  }
}

function abortJob(requestId) {
  const job = activeFirmwareDownloads.get(requestId);
  if (!job) return;
  job.controller.abort();
  finishJob(requestId);
}

function abortAllJobs() {
  for (const [id, job] of activeFirmwareDownloads) {
    job.controller.abort();
    stopJobHeartbeat(job);
    activeFirmwareDownloads.delete(id);
  }
}

function onSwMessage(message) {
  if (!message || typeof message !== "object") return;

  if (message.type === "PANDONYMUS_OFFSCREEN_PING") {
    return;
  }

  if (message.type === "PANDONYMUS_FIRMWARE_HEARTBEAT") {
    const job = activeFirmwareDownloads.get(message.requestId);
    postFirmwareChunk({
      requestId: message.requestId,
      heartbeat: true,
      offset: job?.offset ?? message.resumeOffset ?? 0,
      waitingFirst: job ? job.waitingFirst : true,
      portOpen: true,
    });
    return;
  }

  if (message.type === "PANDONYMUS_FIRMWARE_ACK") {
    const job = activeFirmwareDownloads.get(message.requestId);
    if (!job) return;
    if (typeof message.offset === "number" && Number.isFinite(message.offset)) {
      job.ackedOffset = Math.max(job.ackedOffset, message.offset);
    }
    if (message.binaryOk === false) {
      job.useBase64 = true;
      job.chunkBytes = Math.min(BASE64_CHUNK_BYTES, STREAM_CHUNK_BYTES);
    }
    if (job.resolveFirstAck) job.resolveFirstAck();
    else job.firstAcked = true;
    return;
  }

  if (message.type === "PANDONYMUS_FIRMWARE_USE_BASE64") {
    const job = activeFirmwareDownloads.get(message.requestId);
    if (job) {
      job.useBase64 = true;
      job.chunkBytes = Math.min(BASE64_CHUNK_BYTES, STREAM_CHUNK_BYTES);
    }
    return;
  }

  if (message.type === "PANDONYMUS_FIRMWARE_ABORT") {
    abortJob(message.requestId);
    return;
  }

  if (message.type !== "PANDONYMUS_FIRMWARE_START") return;
  const requestId = message.requestId;
  const url = message.url;
  if (!requestId || !url) {
    postFirmwareChunk({ requestId, error: "Solicitud de descarga invalida.", done: true });
    return;
  }
  if (!isAllowedFirmwareUrl(url)) {
    postFirmwareChunk({
      requestId,
      error: `Host de firmware no permitido: ${hostOf(url)}. Solo CDN Lenovo/Motorola.`,
      done: true,
    });
    return;
  }
  void streamFirmwareDownload(requestId, url, message.resumeOffset || 0);
}

function connectSw() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = 0;
  }
  try {
    const port = chrome.runtime.connect({ name: "PANDONYMUS_FIRMWARE_OFFSCREEN" });
    if (chrome.runtime.lastError) {
      reconnectTimer = setTimeout(connectSw, 400);
      return;
    }
    swPort = port;
    port.onMessage.addListener(onSwMessage);
    port.onDisconnect.addListener(() => {
      swPort = null;
      abortAllJobs();
      reconnectTimer = setTimeout(connectSw, 250);
    });
  } catch {
    reconnectTimer = setTimeout(connectSw, 500);
  }
}

connectSw();
